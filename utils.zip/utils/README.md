# Directory for helpers modules

## prompter.py

Prompter class, a template manager.

`from utils.prompter import Prompter`

## callbacks.py

Helpers to support streaming generate output.

`from utils.callbacks import Iteratorize, Stream`
